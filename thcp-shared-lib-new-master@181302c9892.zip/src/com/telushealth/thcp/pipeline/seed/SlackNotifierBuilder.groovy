package util.thcp.jobdsl

import java.util.logging.Logger
import groovy.transform.builder.Builder
import groovy.transform.builder.SimpleStrategy
import jenkins.model.Jenkins

@Builder(builderStrategy = SimpleStrategy, prefix = '')
public class SlackNotifierBuilder {

    private static final Logger log = Logger.getLogger(SlackNotifierBuilder.class.name)

    String teamDomain = ''
    String tokenCredentialId = ''
    String room = ''
    String baseUrl = ''
    String botUser = ''

    void build () {
        def instance = Jenkins.getInstance()
        def slack = instance.getExtensionList('jenkins.plugins.slack.SlackNotifier$DescriptorImpl')[0]

        boolean save = false
        
        if(teamDomain != slack.teamDomain) {
            slack.teamDomain = teamDomain
            save = true
        }
        if(tokenCredentialId != slack.tokenCredentialId) {
            slack.tokenCredentialId = tokenCredentialId
            save = true
        }
        if(room != slack.room) {
            slack.room = room
            save = true
        }
        if(baseUrl != slack.baseUrl) {
            slack.baseUrl = baseUrl
            save = true
        }
        if(botUser != slack.botUser) {
            slack.botUser = botUser
            save = true
        }
        if(save) {
            log.info('Slack configured.')
            slack.save()
        }
        else {
            log.info('Nothing changed.  Slack already configured.')
        }
    }
}