package com.telushealth.thcp.pipeline.seed

import groovy.transform.builder.Builder
import groovy.transform.builder.SimpleStrategy
import javaposse.jobdsl.dsl.DslFactory
import javaposse.jobdsl.dsl.Job
import javaposse.jobdsl.dsl.jobs.OrganizationFolderJob

@Builder(builderStrategy = SimpleStrategy, prefix = '')
public class OrganizationFolderBuilder {

    String folder
    String repoKey
    String displayName
    String description
    String serverUrl
    String bitBucketCredentialsId
    String checkoutCredentialsId
    String branchesToBuildAutomatically
    Integer numOfBuildsToKeep = 25
    Boolean checkoutLocalBranch = false
  	String jenkinsFilePath = 'Jenkinsfile'
    Boolean wipeOutRepo = false
    Boolean cleanBeforeCheckout = false

    OrganizationFolderJob build (DslFactory dslFactory) {
        dslFactory.organizationFolder("${folder}/${repoKey}") {
            description(description)
            displayName(displayName)
            primaryView(folder)
            organizations {
                bitbucket {
                    serverUrl(serverUrl)
                    credentialsId(bitBucketCredentialsId)
                    repoOwner(repoKey)
                }
            }
            configure { node ->
                node / navigators / 'com.cloudbees.jenkins.plugins.bitbucket.BitbucketSCMNavigator' / traits {
                    def traits = ''
                    traits << 'com.cloudbees.jenkins.plugins.bitbucket.BranchDiscoveryTrait' {
                        strategyId('1')
                    }
                    traits << 'com.cloudbees.jenkins.plugins.bitbucket.OriginPullRequestDiscoveryTrait' {
                        strategyId('1')
                    }
                    traits << 'com.cloudbees.jenkins.plugins.bitbucket.ForkPullRequestDiscoveryTrait' {
                        strategyId('1')
                        trust(class: 'com.cloudbees.jenkins.plugins.bitbucket.ForkPullRequestDiscoveryTrait$TrustTeamForks')
                    }
                    traits << 'com.cloudbees.jenkins.plugins.bitbucket.TagDiscoveryTrait' {
                    }
                    traits << 'jenkins.plugins.git.traits.CloneOptionTrait'(plugin: 'git@3.9.1') {
                        extension(class: 'hudson.plugins.git.extensions.impl.CloneOption') {
                            shallow(false)
                            noTags(false)
                            depth(0)
                            honorRefspec(false)
                        }
                    }
                    if (checkoutCredentialsId != null) {
                        traits << 'com.cloudbees.jenkins.plugins.bitbucket.SSHCheckoutTrait' {
                            credentialsId(checkoutCredentialsId)
                        }
                    }
                    if (checkoutLocalBranch) {
                        traits << 'jenkins.plugins.git.traits.LocalBranchTrait'(plugin: 'git@3.9.3') {
                            extension(class: 'hudson.plugins.git.extensions.impl.LocalBranch') {
                                localBranch('**')
                            }
                        }
                    }
                    if(cleanBeforeCheckout) {
                        traits << 'jenkins.plugins.git.traits.CleanBeforeCheckoutTrait'(plugin: 'git@3.9.3') {
                            extension(class: 'hudson.plugins.git.extensions.impl.CleanBeforeCheckout') 
                        }
                    }
                    if(wipeOutRepo) {
                        traits << 'jenkins.plugins.git.traits.WipeWorkspaceTrait'(plugin: 'git@3.9.3') {
                            extension(class: 'hudson.plugins.git.extensions.impl.WipeWorkspace')
                        }
                    }
                }
                node / buildStrategies / 'jenkins.branch.buildstrategies.basic.NamedBranchBuildStrategyImpl' / filters {
                    def filters = ''
                    filters << 'jenkins.branch.buildstrategies.basic.NamedBranchBuildStrategyImpl_-RegexNameFilter' {
                        regex(branchesToBuildAutomatically)
                        caseSensitive(true)
                    }
                }
            }
            triggers {
                periodic(1440)
            }
            projectFactories { 
                workflowMultiBranchProjectFactory {
                    scriptPath(jenkinsFilePath)
                }
            }
        }
    }
}
