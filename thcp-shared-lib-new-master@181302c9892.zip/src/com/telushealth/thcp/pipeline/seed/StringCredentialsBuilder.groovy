package util.thcp.jobdsl

import hudson.util.Secret
import groovy.transform.builder.Builder
import groovy.transform.builder.SimpleStrategy
import com.cloudbees.plugins.credentials.CredentialsScope
import com.cloudbees.plugins.credentials.Credentials
import org.jenkinsci.plugins.plaincredentials.impl.StringCredentialsImpl

@Builder(builderStrategy = SimpleStrategy, prefix = '')
public class StringCredentialsBuilder extends BaseCredentialsBuilder {

    Credentials getCredentials () {
         Credentials c = (Credentials) new StringCredentialsImpl(CredentialsScope.GLOBAL, 
            id, 
            description, 
            Secret.decrypt(secret)
         )
        return c
    }
}