package util.thcp.jobdsl

import java.util.logging.Logger
import groovy.transform.builder.Builder
import groovy.transform.builder.SimpleStrategy
import jenkins.model.Jenkins
import org.jfrog.hudson.ArtifactoryServer
import org.jfrog.hudson.CredentialsConfig

@Builder(builderStrategy = SimpleStrategy, prefix = '')
public class ArtifactoryBuilder {

    private static final Logger log = Logger.getLogger(ArtifactoryBuilder.class.name)

    String serverName
    String serverUrl
    String deployerCredentialId
    String resolverCredentialId

    void build () {
        def instance = Jenkins.getInstance()
        def desc = instance.getDescriptor("org.jfrog.hudson.ArtifactoryBuilder")
        def exists = false

        desc.getArtifactoryServers().each {
            if (it.name == serverName) {
                exists = true
                log.info('Artifactory server exists: ' + it.name)
                return true
            }
        }

        if (!exists) {
            log.info('Creating new Artifactory server: ' + serverName)
            def sinst = [
                new ArtifactoryServer(
                    serverName,
                    serverUrl,
                    new CredentialsConfig(null, null, deployerCredentialId),
                    new CredentialsConfig(null, null, resolverCredentialId),
                    300,
                    false,
                    3
                )
            ]

            desc.setUseCredentialsPlugin(true)
            desc.setArtifactoryServers(sinst)
        }
    }
}