package util.thcp.jobdsl

import groovy.transform.builder.Builder
import groovy.transform.builder.SimpleStrategy
import com.cloudbees.plugins.credentials.Credentials
import com.cloudbees.plugins.credentials.SystemCredentialsProvider
import com.cloudbees.plugins.credentials.domains.Domain

@Builder(builderStrategy = SimpleStrategy, prefix = '')
public abstract class BaseCredentialsBuilder {
    String id
    String description
    String secret

    abstract Credentials getCredentials ()

    void build () {
        Boolean exists = false
        Credentials c = getCredentials()
        SystemCredentialsProvider.getInstance().getStore().getCredentials(Domain.global()).each {
            if (it.id == c.id) {
                SystemCredentialsProvider.getInstance().getStore().updateCredentials(Domain.global(), it, c)
                exists = true
                return true
            }
        }
        
        if (!exists) {
            SystemCredentialsProvider.getInstance().getStore().addCredentials(Domain.global(), c)
        }
    }
}