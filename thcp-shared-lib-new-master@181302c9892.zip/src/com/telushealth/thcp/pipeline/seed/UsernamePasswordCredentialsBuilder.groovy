package util.thcp.jobdsl

import groovy.transform.builder.Builder
import groovy.transform.builder.SimpleStrategy
import com.cloudbees.plugins.credentials.CredentialsScope
import com.cloudbees.plugins.credentials.Credentials
import com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl

@Builder(builderStrategy = SimpleStrategy, prefix = '')
public class UsernamePasswordCredentialsBuilder extends BaseCredentialsBuilder {

    String user

    Credentials getCredentials () {
         Credentials c = (Credentials) new UsernamePasswordCredentialsImpl(CredentialsScope.GLOBAL, 
            id, 
            description, 
            user, 
            secret)
        return c
    }
}