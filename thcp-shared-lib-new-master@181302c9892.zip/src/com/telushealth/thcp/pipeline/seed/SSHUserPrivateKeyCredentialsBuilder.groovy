package util.thcp.jobdsl

import hudson.util.Secret
import groovy.transform.builder.Builder
import groovy.transform.builder.SimpleStrategy
import com.cloudbees.plugins.credentials.CredentialsScope
import com.cloudbees.plugins.credentials.Credentials
import com.cloudbees.jenkins.plugins.sshcredentials.impl.BasicSSHUserPrivateKey 

@Builder(builderStrategy = SimpleStrategy, prefix = '')
public class SSHUserPrivateKeyCredentialsBuilder extends  BaseCredentialsBuilder {

    String user

    Credentials getCredentials () {
         Credentials c = (Credentials) new BasicSSHUserPrivateKey(CredentialsScope.GLOBAL, 
            id,
            user,
            new BasicSSHUserPrivateKey.DirectEntryPrivateKeySource(Secret.decrypt(secret)),
            null,
            description, )
        return c
    }
}