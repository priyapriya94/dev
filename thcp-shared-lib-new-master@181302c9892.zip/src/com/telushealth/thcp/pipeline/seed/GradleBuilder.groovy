package util.thcp.jobdsl

import java.util.logging.Logger
import groovy.transform.builder.Builder
import groovy.transform.builder.SimpleStrategy
import jenkins.model.Jenkins
import hudson.tools.ToolInstallation
import hudson.plugins.gradle.GradleInstallation
import hudson.plugins.gradle.GradleInstaller
import hudson.tools.InstallSourceProperty

@Builder(builderStrategy = SimpleStrategy, prefix = '')
public class GradleBuilder {

    private static final Logger log = Logger.getLogger(GradleBuilder.class.name)

    String name
    String version

    void build () {
        def instance = Jenkins.getInstance()
        def gradleInstallationDescriptor = instance.getDescriptor('hudson.plugins.gradle.GradleInstallation')
        def installations = gradleInstallationDescriptor.getInstallations()
        def exists = false
        def installers = [new GradleInstaller(version)]
        def gradleInstaller = new InstallSourceProperty(installers)
        def gradleTool = new GradleInstallation(name, '', [gradleInstaller])

        installations.each {
            if (gradleTool.name == it.name) {
                exists = true
                log.info('Found existing installation: ' + gradleTool.name)
                return true
            }
            
        }

        if (!exists) {
            log.info('Creating new gradle installation: ' + gradleTool.name)

            gradleInstallationDescriptor.setInstallations((ToolInstallation)gradleTool)
            gradleInstallationDescriptor.save()
        }
    }
}