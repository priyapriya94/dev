import groovy.OrganizationFolderBuilder
import groovy.Project

new Project().getProjects().each { p ->
  new OrganizationFolderBuilder().
    project(p).
    build(this)
}
