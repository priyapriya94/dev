package groovy

import groovy.ProjectInfo
import groovy.transform.builder.Builder
import groovy.transform.builder.SimpleStrategy
import javaposse.jobdsl.dsl.DslFactory
import javaposse.jobdsl.dsl.jobs.OrganizationFolderJob

@Builder(builderStrategy = SimpleStrategy, prefix = '')
class OrganizationFolderBuilder {

    ProjectInfo project
    String serverUrl = 'https://bitbucket.tools.telushealth.com'
    String bitBucketCredentialsId = 'bitbucket-user'
    String checkoutCredentialsId = 'jenkins-private-key'
    Boolean checkoutLocalBranch = false
  	String jenkinsFilePath = 'Jenkinsfile'
    Boolean wipeOutRepo = false
    Boolean cleanBeforeCheckout = false

    OrganizationFolderJob build (DslFactory dslFactory) {
        dslFactory.folder(project.folder)
        dslFactory.listView( project.folder,{
            description(project.description)
            recurse()
            jobs {
                regex(/APT\/[A-Z]+\/[a-z0-9-]+/)
            }
            columns {
                status()
                weather()
                name()
                lastSuccess()
                lastFailure()
                lastDuration()
                buildButton()
            }
        })
        OrganizationFolderJob folderJob = dslFactory.organizationFolder("${project.folder}/${project.repoKey}") {
            description(project.description)
            displayName(project.displayName)
            primaryView(project.folder)
            organizations {
                bitbucket {
                    serverUrl(serverUrl)
                    credentialsId(bitBucketCredentialsId)
                    repoOwner(project.repoKey)
                }
            }
            orphanedItemStrategy {
                discardOldItems {
                    numToKeep(project.numOfBuildsToKeep)
                }
            }
            configure { node ->
                node / navigators / 'com.cloudbees.jenkins.plugins.bitbucket.BitbucketSCMNavigator' / traits {
                    def traits = ''
                    traits << 'com.cloudbees.jenkins.plugins.bitbucket.BranchDiscoveryTrait' {
                        strategyId('1')
                    }
                    traits << 'com.cloudbees.jenkins.plugins.bitbucket.OriginPullRequestDiscoveryTrait' {
                        strategyId('1')
                    }
                    traits << 'com.cloudbees.jenkins.plugins.bitbucket.ForkPullRequestDiscoveryTrait' {
                        strategyId('1')
                        trust(class: 'com.cloudbees.jenkins.plugins.bitbucket.ForkPullRequestDiscoveryTrait$TrustTeamForks')
                    }
                    traits << 'com.cloudbees.jenkins.plugins.bitbucket.TagDiscoveryTrait' {
                    }
                    traits << 'jenkins.plugins.git.traits.CloneOptionTrait'(plugin: 'git@3.9.1') {
                        extension(class: 'hudson.plugins.git.extensions.impl.CloneOption') {
                            shallow(false)
                            noTags(false)
                            depth(0)
                            honorRefspec(false)
                        }
                    }
                    if (checkoutCredentialsId != null) {
                        traits << 'com.cloudbees.jenkins.plugins.bitbucket.SSHCheckoutTrait' {
                            credentialsId(checkoutCredentialsId)
                        }
                    }
                    if (checkoutLocalBranch) {
                        traits << 'jenkins.plugins.git.traits.LocalBranchTrait'(plugin: 'git@3.9.3') {
                            extension(class: 'hudson.plugins.git.extensions.impl.LocalBranch') {
                                localBranch('**')
                            }
                        }
                    }
                    if(cleanBeforeCheckout) {
                        traits << 'jenkins.plugins.git.traits.CleanBeforeCheckoutTrait'(plugin: 'git@3.9.3') {
                            extension(class: 'hudson.plugins.git.extensions.impl.CleanBeforeCheckout') 
                        }
                    }
                    if(wipeOutRepo) {
                        traits << 'jenkins.plugins.git.traits.WipeWorkspaceTrait'(plugin: 'git@3.9.3') {
                            extension(class: 'hudson.plugins.git.extensions.impl.WipeWorkspace')
                        }
                    }
                }
                node / buildStrategies / 'jenkins.branch.buildstrategies.basic.NamedBranchBuildStrategyImpl' / filters {
                    def filters = ''
                    filters << 'jenkins.branch.buildstrategies.basic.NamedBranchBuildStrategyImpl_-RegexNameFilter' {
                        regex(project.branchesToBuildAutomatically)
                        caseSensitive(true)
                    }
                }
                node / 'properties' << 'jenkins.branch.NoTriggerOrganizationFolderProperty'{
                    def noTriggerBranch = '.*'
                    if(project.branchesToBuildAutomatically != 'none') {
                        noTriggerBranch = project.branchesToBuildAutomatically
                    }
                    branches(noTriggerBranch)
                }
            }
            triggers {
                periodic(1440)
            }
            projectFactories { 
                workflowMultiBranchProjectFactory {
                    scriptPath(jenkinsFilePath)
                }
            }
        }
        dslFactory.queue("${project.folder}/job/${project.repoKey}")
        return folderJob
    }
}
