package lib

import groovy.transform.builder.Builder
import groovy.transform.builder.SimpleStrategy

@Builder(builderStrategy = SimpleStrategy, prefix = '')
class ProjectInfo implements Serializable {
    String folder
    String repoKey
    String displayName
    String description
    String branchesToBuildAutomatically
    int numOfBuildsToKeep

    ProjectInfo(String folder, String repoKey, String displayName, String desc, String branchesToBuildAutomatically, int numOfBuildsToKeep) {
        this.folder = folder
        this.repoKey = repoKey
        this.displayName = displayName
        this.description = desc
        this.branchesToBuildAutomatically = branchesToBuildAutomatically
        this.numOfBuildsToKeep = numOfBuildsToKeep
    }
}
