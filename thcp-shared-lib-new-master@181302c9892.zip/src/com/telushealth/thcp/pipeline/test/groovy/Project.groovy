package groovy

import groovy.ProjectInfo

def getProjects() {
  List<ProjectInfo> projects = [
    //folder, project key, project name, project description, branchesToBuildAuto, NumOfBuildToKeep
    new ProjectInfo('TA', 'TAAMI', 'TA Cloud AMI', 'TA Cloud AMI baking jobs', 'none', 10)
  ]
  return projects
}

return this
